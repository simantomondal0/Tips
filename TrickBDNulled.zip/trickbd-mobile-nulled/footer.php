</div>

    <div id="f_link"  style="margin-top: 4px; padding:9px;background:#333333;border-top:4px solid #3399ff" class="mfooter">

<div class="mtt">
<a href="http://fb.com/#"><img alt="Facebook" src="<?php echo get_template_directory_uri(); ?>/img/fb.png"/></a> 
<a href="http://twitter.com/#"><img alt="Twitter" src="<?php echo get_template_directory_uri(); ?>/img/twitter.png"/></a>  
<a href="http://plus.google.com/u/0/#">
<img alt="Google plus" src="<?php echo get_template_directory_uri(); ?>/img/google.png"/></a>  
<a href="hhttp://www.youtube.com/channel/#"><img alt="Youtube" src="<?php echo get_template_directory_uri(); ?>/img/youtube.png"/></a> 

 <a href="#top">
<span style="float: right">
<img alt="Back to top" src="<?php echo get_template_directory_uri(); ?>/img/57.png"/></span></a></div>
<div class="mtb"></div>
<ul class="mleft">
	<li> <a href="<?php bloginfo('url' );?>">Home</a></li>
	<li> <a href="/aboutus">About us</a></li>
	<li><a href="/contactus">Contact us</a></li>
	<li> <a href="/crivacypolicy">Privacy policy </a></li>
</ul>
	<ul class="mright">
	<li><a href="/disclaimer">Disclaimer</a></li>
	<li><a href="/copyrightissue">Copyright issue </a></li>
</ul>
<div style="clear: both; display: block"></div></div>
<div class="clear"></div>
                    	<div class="block_fotter" style="color:#fff">Copyright &#169; <?php print(date(Y)); ?> <?php bloginfo('name'); ?> | Nulled by <a href="http://howtrick.com" title="">HowTrick.Com</a></div> 
               

        

    
    <?php wp_footer(); ?>

</body>
</html>
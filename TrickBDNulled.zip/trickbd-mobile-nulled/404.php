<?php get_header(); ?> 
             
        <div class="entry"> 
        

                                <div style="background:#fff;color:#333">
                    
<h2>Error 404! Page not found!</h2><br /><br />
                                    
                                </div>
         
        
        </div> <!--entry-->
        
  
<div align="center">
</div>
		<?php dynamic_sidebar('Categories'); ?>	


        <?php get_footer(); ?>        
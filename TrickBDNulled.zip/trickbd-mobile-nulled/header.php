<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php wp_title(); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
	<?php wp_head(); ?>

</head>

<body>

    <div id="top" class="block_header">
        <table class="header_logo" width="100%">
            <td>
                <a href="<?php bloginfo('url') ;?>" title="<?php bloginfo('name' );?>" rel="home" style="margin-left:10px">
					<img src="<?php echo get_template_directory_uri();?>/img/logo.png"/>				
				</a>
				
            </td>
			<?php if (is_user_logged_in() ): ?>
				<td width="90px" align="right"> 
					<a class="login_box" href="<?php bloginfo('url') ;?>/new-post/">New post</a>
				</td>
				<td width="50px" align="right">
					<a class="login_box" href="<?php echo wp_logout_url() ;?>">logout</a>
				</td> 
			<?php else: ?>
			<td width="50px" align="right"> 
					<a class="login_box" href="<?php echo wp_login_url( home_url() ); ?>">Login</a>
			</td>
			<td width="50px" align="right">
				<a class="login_box" href="<?php bloginfo('url') ;?>/wp-login.php?action=register">Signup</a>
			</td>   
			<?php endif ?>
		</table>
		<div class="main_nav">
			<div class="menu-mobile-nav-container">
			<ul id="menu-mobile-nav" class="menu"><li><a href="<?php bloginfo('url') ;?>">Home</a></li>
			<?php if (is_user_logged_in() ): ?>
				<li><a href="<?php bloginfo('url') ;?>/dashboard/">Dashboard</a></li>
				<li><a href="<?php bloginfo('url') ;?>/profile/">Edit Profile</a></li>
			<?php else: ?>
			
			<?php endif ?>

</ul></div>		</div>
        
    </div><div align="center">
<div class="clear"></div>

<div class="clear"></div></div>
<div style="background-attachment: scroll;background-clip: border-box;background-color:#e6da9b;background-image: none;background-origin: padding-box;background-position: 0 0;background-repeat: repeat;background-size: auto auto;color: #000;font-size: 17px;font-weight: bold;margin-top: 5px;padding-bottom: 10px;padding-left: 8px;padding-right: 8px;padding-top: 10px;" align="center" ><iframe src="http://www.facebook.com/plugins/like.php?href=https://m.facebook.com/mirazmacinfo&amp;width&amp;layout=button_count&amp;action=like&amp;show_faces=false&amp;share=true&amp;height=21&amp;appId=196052093932851" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:150px;height:21px;" allowTransparency="true"></iframe>
</a> 
		</div>

<div class="clear"></div></div>
<?php get_header(); ?> 
   
           <?php if(have_posts()) : ?>
           <?php while(have_posts()) : the_post(); ?> 
		   
  <div class="breadcumbs_single"><?php if ( function_exists('yoast_breadcrumb') ) 
{yoast_breadcrumb('<p id="breadcrumbs">','</p>');} ?></div>
 <div class="block_single">
 <h1><?php the_title(); ?></h1>



<div class="post_paragraph">
<p><?php the_content('Read the rest of this entry &raquo;'); ?>

<div class="clear"></div>
<div class="clear"></div>

</p>
</div>


</div>


<div class="author_block">
<h2><span class="fleft">About Author</span> <span class="fright"><?php if(function_exists('the_views')) { the_views(); } ?></span></h2>
<div class="author_single">
<table width="100%">
	<td class="avata_post"><?php echo get_avatar(2, '60' ); ?></td>
	<td class="author_name">

	About <?php the_author_posts_link(); ?>	
	<p><?php the_author_meta('description'); ?></p>
	</td>
</table>
</div>
</div>


                             <div class="block_posts">
<h2>Related Posts</h2>
								<ul class="rpul">
			<?php
					if ( is_single()) {
					$categories = get_the_category();
					if ($categories) {
					foreach ($categories as $category) {
					$cat = $category->cat_ID;
					$args=array(
					'cat' => $cat,
					'order' =>DESC,
					'orderby' => rand,
					'post__not_in' => array($post->ID),
					'posts_per_page'=>5,
					'caller_get_posts'=>3
					);
					$my_query = null;
					$my_query = new WP_Query($args);
					if( $my_query->have_posts() ) {
					echo ' ';
					echo '<ul>';
					while ($my_query->have_posts()) : $my_query->the_post(); ?>
					
	<li>
										<?php the_post_thumbnail('post-image', array('class' => 'post-thumb')); ?>
											                <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
												<p><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' ago'; ?> <?php comments_popup_link('No Comment', '1  Comment', '% comments'); ?> <font color="gray"> <?php if(function_exists('the_views')) { the_views(); } ?></font></p>
										</li>
				 <?php
					endwhile;
					}}} wp_reset_query(); }
					?>
                					</ul>
	</div><!-- END related-posts -->
    <div class="clear"></div>
    
    </div>
<!-- END single-wrap -->     
<div class="block_comment">
                    <?php comments_template(); ?>                   
</div>

                                    <?php endwhile; ?>
                   
                                    <?php endif; ?>



    
	
        <?php get_footer(); ?>        
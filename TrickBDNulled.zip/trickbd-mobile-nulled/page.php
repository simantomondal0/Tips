<?php get_header(); ?> 
    		<?php if(have_posts()) : ?><?php while(have_posts())  : the_post(); ?>   
<div class="breadcumbs_single"><a href="http://howtrick.com">Home</a> &rsaquo; <span class="current"><?php the_title(); ?></span></div></div>

	
 <div class="block_single">
				        
			<h1><?php the_title(); ?></h1>
			<div class="post_paragraph">
			<p> 
			 <?php the_content('Read the rest of this entry &raquo;'); ?>
			</p>
			</div>
		    
		</div>

			<?php endwhile; ?>
			<?php else : ?>
			<h3><?php _e('404 Error&#58; Not Found'); ?></h3>
		<?php endif; ?> 

<?php get_footer(); ?>        